//
//  RxSwiftTestModel.swift
//  yinuo
//
//  Created by 吴承炽 on 2019/9/11.
//  Copyright © 2019年 yinuo. All rights reserved.
//

import UIKit

//歌曲结构体
struct RxSwiftTestModel {
    let name: String //歌名
    let tag: Int //演唱者
    
    init(name: String, tag: Int) {
        self.name = name
        self.tag = tag
    }
}

//实现 CustomStringConvertible 协议，方便输出调试
extension RxSwiftTestModel: CustomStringConvertible {
    var description: String {
        return "name：\(name) singer：\(tag)"
    }
}
