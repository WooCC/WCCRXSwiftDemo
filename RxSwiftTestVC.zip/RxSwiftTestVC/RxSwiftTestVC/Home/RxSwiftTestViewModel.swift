//
//  RxSwiftTestViewModel.swift
//  yinuo
//
//  Created by 吴承炽 on 2019/9/11.
//  Copyright © 2019年 yinuo. All rights reserved.
//

import Foundation
import RxSwift

/*
    Tradition
 */
//struct RxSwiftTestViewModel {
//    let data = [
//            RxSwiftTestModel(name: "UILabel", tag: 0),
//            RxSwiftTestModel(name: "iOS1", tag: 1),
//            RxSwiftTestModel(name: "iOS1", tag: 2),
//            RxSwiftTestModel(name: "iOS1", tag: 3),
//        ]
//
//}

/*
    RxSwift
 */
struct RxSwiftTestViewModel {
    let data = Observable.just([
            RxSwiftTestModel(name: "UILabel", tag: 0),
            RxSwiftTestModel(name: "UITextField", tag: 1),
            RxSwiftTestModel(name: "怎么去看", tag: 2),
            RxSwiftTestModel(name: "iOS1", tag: 3),
        ])
}
