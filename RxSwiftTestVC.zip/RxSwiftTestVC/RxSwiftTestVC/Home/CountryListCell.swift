//
//  CountryListCell.swift
//  yinuo
//
//  Created by 吴承炽 on 2018/10/5.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit
import SnapKit

class CountryListCell: UITableViewCell {
    
    var padding = 10
    
    var titleL = UILabel()
   
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupUI()
    }
    
    private func setupUI() {
        contentView.addSubview(titleL)
        titleL.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().offset(padding)
        }
  
    }
   
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // 解决 UITableViewCell被选中或者高亮的时候，它的所有子view的颜色被自动改变
    override func setHighlighted(_ highlighted: Bool, animated: Bool) {
        super.setHighlighted(highlighted, animated: animated)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}


