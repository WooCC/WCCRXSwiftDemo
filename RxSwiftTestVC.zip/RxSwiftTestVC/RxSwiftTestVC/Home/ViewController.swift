//
//  ViewController.swift
//  RxSwiftTestVC
//
//  Created by 吴承炽 on 2019/9/11.
//  Copyright © 2019年 Wcc. All rights reserved.
//

import UIKit
import SnapKit
import RxSwift
import RxCocoa

class ViewController: UIViewController {
    
    //tableView对象
    var tableView = UITableView()
    
    //歌曲列表数据源
    let musicListViewModel = RxSwiftTestViewModel()
    
    //负责对象销毁
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.center.width.height.equalToSuperview()
        }
        //设置代理
//        tableView.dataSource = self
//        tableView.delegate = self
        
        tableView.registerClassOf(CountryListCell.self)
        //将数据源数据绑定到tableView上
        musicListViewModel.data
            .bind(to: tableView.rx.items(cellIdentifier:CountryListCell.self.demo_reuseIdentifier)) { _, music, cell in
                cell.textLabel?.text = music.name
            }.disposed(by: disposeBag)
        //tableView点击响应
        tableView.rx.modelSelected(RxSwiftTestModel.self).subscribe(onNext: { music in
            self.pushVC(tag: music.tag)
        }).disposed(by: disposeBag)
    }
    
    func pushVC(tag:Int) {
        switch tag {
        case 0:
            let vc = LabelVC()
            self.present(vc, animated: true) {}
        case 1:
            let vc = TextFieldVC()
            self.present(vc, animated: true) {}
        case 2:
            let vc = HowToReadVC()
            self.present(vc, animated: true) {}
        case 3:
            let vc = LabelVC()
            self.present(vc, animated: true) {}
        default: break
        }
    }
    
}

/*
    Tradition
 */
//extension ViewController: UITableViewDataSource {
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return musicListViewModel.data.count
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath)
//        -> UITableViewCell {
//            let cell = tableView.dequeueReusableCell(withIdentifier: "CountryListCell", for: indexPath) as! CountryListCell
//            let music = musicListViewModel.data[indexPath.row]
//            cell.textLabel?.text = music.name
//            return cell
//    }
//}
//extension ViewController: UITableViewDelegate {
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        print("你选中的歌曲信息【\(musicListViewModel.data[indexPath.row])】")
//    }
//}




extension UITableView{
    // 注册cell
    func registerClassOf<T: UITableViewCell>(_: T.Type) {
        register(T.self, forCellReuseIdentifier: T.demo_reuseIdentifier)
    }
    
    // 获取cell
    func dequeueReusableCell<T: UITableViewCell>() -> T {
        guard let cell = dequeueReusableCell(withIdentifier: T.demo_reuseIdentifier) as? T else {
            fatalError("获取Cell失败,ID: \(T.demo_reuseIdentifier)")
        }
        return cell
    }
}

protocol Reusable: class {
    static var demo_reuseIdentifier: String { get }
}

extension UITableViewCell: Reusable {
    
    static var demo_reuseIdentifier: String {
        return String(describing: self)
    }
}

