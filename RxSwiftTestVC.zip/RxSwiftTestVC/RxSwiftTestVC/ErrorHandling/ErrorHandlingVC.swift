//
//  ErrorHandlingVC.swift
//  RxSwiftTestVC
//
//  Created by 吴承炽 on 2019/9/11.
//  Copyright © 2019年 Wcc. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

enum MyError: Error {
    case A
    case B
}

class ErrorHandlingVC: UIViewController {
    
    let disposeBag = DisposeBag()
    
    let label = UILabel()
    let btn = UIButton()
    
    override func viewDidLoad() {
        self.view.backgroundColor = .white
        
        errorHandleDemo()
        //--------------------------------------------------
        setUpLabel()
        setUpButton()
    }
    
    func errorHandleDemo() {
        
    }
    
    func setUpLabel() {
        //创建文本标签
        self.view.addSubview(label)
        label.snp.makeConstraints { (make) in
            make.center.width.equalToSuperview()
        }
        label.textAlignment = .center
        label.text = "错误处理"
        
    }
    func setUpButton() {
        self.view.addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.top.equalTo(label.snp.bottom).offset(10)
            make.width.height.equalTo(50)
            make.centerX.equalToSuperview()
        }
        
        btn.setTitle("Back", for: .normal)
        btn.backgroundColor = .red
        btn.setTitleColor(.white, for: .normal)
        btn.rx.tap
            .subscribe(onNext: { [weak self] in
                self?.dismiss(animated: true) {}
            })
            .disposed(by: disposeBag)
        
    }
    
}

