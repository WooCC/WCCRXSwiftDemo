//
//  TextFieldVC.swift
//  RxSwiftTestVC
//
//  Created by 吴承炽 on 2019/9/11.
//  Copyright © 2019年 Wcc. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class TextFieldVC: UIViewController {
    
    let disposeBag = DisposeBag()
    
    let textField = UITextField()
    let btn = UIButton()
    
    override func viewDidLoad() {
        self.view.backgroundColor = .white
        
        setUpTextField()
        //--------------------------------------------------
        setUpButton()
    }
    
    func setUpTextField() {
        
        self.view.addSubview(textField)
        textField.snp.makeConstraints { (make) in
            make.center.width.equalToSuperview()
            make.height.equalTo(80)
        }
        textField.textAlignment = .center
        textField.borderStyle = .roundedRect
        /*
            editingDidBegin：开始编辑（开始输入内容）
            editingChanged：输入内容发生改变
            editingDidEnd：结束编辑
            editingDidEndOnExit：按下 return 键结束编辑
            allEditingEvents：包含前面的所有编辑相关事件
         */
 
        textField.rx.controlEvent([.editingDidBegin,.editingChanged,.editingDidEnd]) //状态可以组合
            .asObservable()
            .subscribe(onNext: { element in
                print(element)
            }, onError: { error in
                print(error)
            }, onCompleted: {
                print("completed")
            }, onDisposed: {
                print("disposed")
            }).disposed(by: disposeBag)
        
    }
    
    
    
    
    
    func setUpButton() {
        self.view.addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.top.equalTo(textField.snp.bottom).offset(10)
            make.width.height.equalTo(50)
            make.centerX.equalToSuperview()
        }
        
        btn.setTitle("Back", for: .normal)
        btn.backgroundColor = .red
        btn.setTitleColor(.white, for: .normal)
        btn.addTarget(self, action: #selector(dimissClick(_:)), for: .touchUpInside)
        
    }
    @objc func dimissClick(_ sender: UIButton) {
        self.dismiss(animated: true) {
        }
    }
}

