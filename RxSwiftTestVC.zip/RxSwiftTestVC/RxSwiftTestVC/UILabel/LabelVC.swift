//
//  LabelVC.swift
//  RxSwiftTestVC
//
//  Created by 吴承炽 on 2019/9/11.
//  Copyright © 2019年 Wcc. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class LabelVC: UIViewController {
    
    let disposeBag = DisposeBag()
    
    let label = UILabel()
    let btn = UIButton()
    
    override func viewDidLoad() {
        self.view.backgroundColor = .white
        
        setUpLabel()
//--------------------------------------------------
        setUpButton()
    }
    
    func setUpLabel() {
        //创建文本标签
        self.view.addSubview(label)
        label.snp.makeConstraints { (make) in
            make.center.width.equalToSuperview()
        }
        label.textAlignment = .center
        //创建一个计时器（每0.1秒发送一个索引数）
        let timer = Observable<Int>.interval(0.1, scheduler: MainScheduler.instance)
        //将已过去的时间格式化成想要的字符串，并绑定到label上
        timer.map{ String(format: "%0.2d:%0.2d.%0.1d",
                          arguments: [($0 / 600) % 600, ($0 % 600 ) / 10, $0 % 10]) }
            .bind(to: label.rx.text)
            .disposed(by: disposeBag)
    }
    func setUpButton() {
        self.view.addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.top.equalTo(label.snp.bottom).offset(10)
            make.width.height.equalTo(50)
            make.centerX.equalToSuperview()
        }
        
        btn.setTitle("Back", for: .normal)
        btn.backgroundColor = .red
        btn.setTitleColor(.white, for: .normal)
        
        /*
            Tradition
         */
//        btn.addTarget(self, action: #selector(dimissClick(_:)), for: .touchUpInside)
        
        /*
            RxSwift
         */
        btn.rx.tap
            .subscribe(onNext: { [weak self] in
                self?.dismiss(animated: true) {}
            })
            .disposed(by: disposeBag)
        
    }
    @objc func dimissClick(_ sender: UIButton) {
        self.dismiss(animated: true) {}
    }
}
