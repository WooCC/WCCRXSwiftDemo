//
//  HowToReadVC.swift
//  RxSwiftTestVC
//
//  Created by 吴承炽 on 2019/9/11.
//  Copyright © 2019年 Wcc. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class HowToReadVC: UIViewController {
    
    let disposeBag = DisposeBag()
    
    let label = UILabel()
    let btn = UIButton()
    
    override func viewDidLoad() {
        self.view.backgroundColor = .white
//        setUpFirstDemo()
        setUpSecondDemo()
        //--------------------------------------------------
        setUpLabel()
        setUpButton()
    }
    func setUpFirstDemo() {
        Observable.of(2, 30, 22, 5, 60, 3, 40 ,9)
            .filter {
                $0 > 10
            }
            .do(onNext: { element in
                print("Intercepted Next：", element)
            }, onError: { error in
                print("Intercepted Error：", error)
            }, onCompleted: {
                print("Intercepted Completed")
            }, onDispose: {
                print("Intercepted Disposed")
            })
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
        /*
             Observable.of(2, 30, 22, 5, 60, 3, 40 ,9)
         
             just()、of()、from()、empty()等方法就是让我们创建出一个 Observable 序列。
         
             各个方法的详细介绍链接：https://www.jianshu.com/p/63f1681236fd
         */
        
        /*
             .filter {$0 > 10}
         
             .buffer、.map、.filter、.toArray 这些是操作符，当我们有了一个Observable 序列后，
             要对这个序列做一些什么操作，就通过这一系列的操作符对其进行操作。
         
             操作符的详细介绍链接：https://www.jianshu.com/p/c665d49c5c72
         */
        
        /*
             .subscribe(onNext: { print($0) })
         
             .subscribe 就是我们对Observable 序列进行一系列操作后，会做的一系列事件（Even），
             可以参考 TextFieldVC 里面subscribe
         
             .doOn 用来监听这个 Observable 序列的生命周期
         
             详细介绍链接：https://www.jianshu.com/p/4ce3f253dacd
         */
        
        /*
             .disposed(by: disposeBag)
         
             .dispose() 我们用他来取消一个订阅行为
             DisposeBag 我们用他来管理多个订阅行为的销毁，把用过的订阅行为都放进去。
             而这个DisposeBag 就会在自己快要dealloc 的时候，对它里面的所有订阅行为都调用 dispose()方法。
         
             详细介绍链接：https://www.jianshu.com/p/4ce3f253dacd
         */
       
    }
    func setUpSecondDemo() {
        let observable = Observable.of("A", "B", "C")//如果只是单单创建这么一个序列出来，而没人去监听他，那是没用的
        
        //使用subscription常量存储这个订阅方法
        let subscription = observable.subscribe { event in
            print(event)
        }
        
        //调用这个订阅的dispose()方法
        subscription.dispose()
    }
    
    func setUpLabel() {
        //创建文本标签
        self.view.addSubview(label)
        label.snp.makeConstraints { (make) in
            make.center.width.equalToSuperview()
        }
        label.textAlignment = .center
        label.text = "怎么读"
      
    }
    func setUpButton() {
        self.view.addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.top.equalTo(label.snp.bottom).offset(10)
            make.width.height.equalTo(50)
            make.centerX.equalToSuperview()
        }
        
        btn.setTitle("Back", for: .normal)
        btn.backgroundColor = .red
        btn.setTitleColor(.white, for: .normal)
        
        /*
         Tradition
         */
        //        btn.addTarget(self, action: #selector(dimissClick(_:)), for: .touchUpInside)
        
        /*
         RxSwift
         */
        btn.rx.tap
            .subscribe(onNext: { [weak self] in
                self?.dismiss(animated: true) {}
            })
            .disposed(by: disposeBag)
        
    }
    @objc func dimissClick(_ sender: UIButton) {
        self.dismiss(animated: true) {}
    }
}

